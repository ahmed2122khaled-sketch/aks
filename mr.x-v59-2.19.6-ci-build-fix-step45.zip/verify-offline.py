#!/usr/bin/env python3
from pathlib import Path
import re
root=Path(__file__).parent
main=(root/'app/src/main/kotlin/com/socialnetwork/app/ui/MainActivity.kt').read_text()
coord=(root/'app/src/main/kotlin/com/socialnetwork/app/sync/OfflineSyncCoordinator.kt').read_text()
store=(root/'app/src/main/kotlin/com/socialnetwork/app/data/local/OfflineStore.kt').read_text()
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
checks={
 'offline SQLite store': 'class OfflineStore(' in store and 'SQLiteOpenHelper' in store,
 'response cache': 'putCached' in store and 'getCached' in store,
 'pending mutation queue': 'enqueue(' in store and 'pendingOperations' in store,
 'network monitor': 'ConnectivityMonitor' in main and 'registerDefaultNetworkCallback' in (root/'app/src/main/kotlin/com/socialnetwork/app/core/ConnectivityMonitor.kt').read_text(),
 'offline GET fallback': 'networkAvailableAtStart' in main and 'offlineStore.getCached' in main,
 'automatic sync': 'syncPendingOperations' in main and 'delete(' in store,
 'offline media persistence': 'offline-media' in main and 'OFFLINE_POST_URL' in main and 'OFFLINE_STORY_URL' in main,
 'network state permission': 'android.permission.ACCESS_NETWORK_STATE' in manifest,
 'keystore tokens unchanged': 'saveSecret(ACCESS_TOKEN' in main and 'saveSecret(REFRESH_TOKEN' in main,
 'offline mutations are bound to account identity': 'owner_user_id' in store and 'CURRENT_USER_ID' in main and 'pendingOperationBelongsToUser' in main,
 'pending queue is account-scoped during reads': 'pendingOperations(limit: Int, ownerUserId: String?' in store and 'pendingOperations(50, owner)' in coord,
 'retry scheduling is account-scoped': 'hasRetryablePending(maxAttempts: Int, ownerUserId: String?' in store and 'hasRetryablePending(MAX_OFFLINE_SYNC_ATTEMPTS, activeOwner)' in main,
}
for k,v in checks.items(): print(f"[{'PASS' if v else 'FAIL'}] {k}")
raise SystemExit(0 if all(checks.values()) else 1)

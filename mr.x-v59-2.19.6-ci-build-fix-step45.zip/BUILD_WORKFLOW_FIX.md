# GitHub Actions build fix

This repository's Android build workflow is intentionally designed **without** a `chmod +x gradlew` step.

The workflow uses `bash ./gradlew` after locating the project directory, so the build does not depend on the executable-bit metadata of the uploaded ZIP.

If GitHub Actions still displays a step named `Grant execute permission for gradlew`, that run is executing an older workflow file/commit. Do not use **Re-run jobs** on that old run. Push a new commit containing `.github/workflows/android-build.yml`, then run the workflow whose name is:

`Build Android APK - FIXED`

The first build step should show:

`=== BUILD WORKFLOW VERSION: FIXED-2026-09-24 ===`

and there must be no step called `Grant execute permission for gradlew`.

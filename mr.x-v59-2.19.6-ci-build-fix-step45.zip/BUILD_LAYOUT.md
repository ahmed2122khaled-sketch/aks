# GitHub build layout

This repository is intentionally packaged with the Android/Gradle project at the repository root.

Required root files:
- `gradlew`
- `gradlew.bat`
- `settings.gradle.kts`
- `build.gradle.kts`
- `app/`
- `gradle/wrapper/`
- `.github/workflows/android-build.yml`

Do not upload the containing `mrx_final_work/` directory as an extra repository level.

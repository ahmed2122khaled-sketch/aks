# Build Workflow Fix — 2026 Step 45

## Root cause

The GitHub Actions run shown in the provided screenshot fails before Gradle starts:

```text
chmod: cannot access 'gradlew': No such file or directory
```

The workflow was assuming that `gradlew` existed in the GitHub repository root. The checked working copy contains Gradle wrapper files, but the failing GitHub revision does not have `gradlew` at the directory where the workflow runs.

## Fix

The CI workflow is now wrapper-independent:

1. It discovers the Gradle project by `settings.gradle.kts` / `settings.gradle`.
2. It installs Gradle 9.7.1 using `gradle/actions/setup-gradle@v6`.
3. It runs `gradle --no-daemon --stacktrace :app:assembleDebug` directly.
4. It no longer executes `chmod +x gradlew`.
5. It no longer requires `gradlew` to exist in the GitHub checkout.
6. It prints Java and Gradle versions before building.
7. It keeps the Android SDK, Supabase validation, project validation, and APK artifact upload steps.

Gradle's current documentation recommends the Wrapper for normal projects, but `setup-gradle` officially supports installing a specific Gradle version and putting it on PATH. This workflow uses that supported fallback so CI can build even when the repository is missing wrapper files.

## Compatibility

- Android Gradle Plugin: 9.3.2
- Gradle: 9.7.1
- JDK: 17
- compileSdk / targetSdk: 37
- Android SDK Build Tools: 37.0.0

The AGP 9.3 line supports API 37 and requires at least Gradle 9.5.0; Gradle 9.7.1 satisfies that minimum.

## Security

No credentials, service-role keys, keystores, or signing secrets were added to the workflow. Supabase secrets remain supplied through GitHub repository variables/secrets.

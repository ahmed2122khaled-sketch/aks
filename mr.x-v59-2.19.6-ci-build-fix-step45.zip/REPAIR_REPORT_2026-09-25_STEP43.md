# mr.x Full Repair — Step 43 — 2026-09-25

## Scope
One consolidated repair pass over the current Kotlin Android + Supabase project, preserving the previous Step 42 changes.

## Repairs applied
- Migrated the Android build to AGP 9.3.1 built-in Kotlin by removing the legacy `org.jetbrains.kotlin.android` plugin from root/module Gradle files.
- Removed the now-unnecessary Kotlin compiler plugin configuration that depended on the legacy plugin.
- Fixed missing `android.os.Build` import in `MainActivity.kt`.
- Fixed missing network timeout references by wiring them to `AppConstants`.
- Bumped app version to `2.19.5` / versionCode `50`.
- Added a new Supabase security-hardening migration that prevents client-side tampering with profile verification/counters/identity timestamps, post counters/ownership, story views/ownership, message authorship/conversation identity, and notification ownership/content fields.
- Restricted message edits to the original sender and added sender-only message deletion policy.
- Kept existing RLS, HTTPS-only routing, Keystore token storage, offline account binding, media validation, and service isolation intact.

## 2026 compatibility basis
Android 17/API 37 is the current target in this project. Android's 2026 documentation requires compile/target SDK 37 for Android 17 and identifies AGP 9.1.1 as the minimum for API 37; this project uses AGP 9.3.1. AGP 9.3 supports API 37 and JDK 17.

## Verification
Run:
- `python3 verify-completeness.py`
- `python3 verify-hardening.py`
- `python3 verify-regression.py`
- `python3 verify-offline.py`
- `python3 verify-service-isolation.py`
- `python3 verify-native-only.py`
- `python3 verify-security.py`
- `python3 verify-multiserver.py`
- `python3 tools/verify-supabase-config.py`
- `python3 tools/verify-2026-modernization.py`
- `python3 verify-project.py`

The repository environment still lacks a system Gradle/Android SDK, so a real APK/AAB build cannot be truthfully claimed from this environment until the Android toolchain is available.

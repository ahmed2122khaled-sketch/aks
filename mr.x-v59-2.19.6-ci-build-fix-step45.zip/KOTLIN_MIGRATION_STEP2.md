# Kotlin Migration — Step 2

This checkpoint performs a real extraction of small, self-contained helpers from `MainActivityLegacy.java` into `core/KotlinAppUtils.kt`.

Migrated helpers:
- endpoint validation
- constant-time string comparison
- email validation
- username-search normalization
- UUID validation
- path traversal protection
- trusted media URL validation
- media extension detection
- HTTP/API error message extraction
- safe exception message extraction

`MainActivityLegacy.java` now delegates these operations to Kotlin. The legacy activity remains temporarily because the remaining Android lifecycle/UI/network implementation is larger and must be migrated incrementally without replacing working code with an unverified automatic translation.

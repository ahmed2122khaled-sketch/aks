$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$Source = Join-Path $Root 'tools\gradle-bootstrap\GradleBootstrap.kt'
$Out = Join-Path $Root 'gradle\wrapper\gradle-wrapper.jar'
if (-not (Get-Command kotlinc -ErrorAction SilentlyContinue)) { throw 'BUILD BLOCKED: Kotlin compiler (kotlinc) is required to build GradleBootstrap.kt' }
& kotlinc -include-runtime -d $Out $Source
$Manifest = Join-Path $Root 'tools\gradle-bootstrap\manifest.mf'
Set-Content -Path $Manifest -Value @('Manifest-Version: 1.0','Main-Class: GradleBootstrap') -NoNewline
& jar --update --file $Out --manifest $Manifest
(Get-FileHash $Out -Algorithm SHA256).Hash.ToLowerInvariant() | ForEach-Object { "$_  gradle-wrapper.jar" } | Set-Content (Join-Path $Root 'gradle\wrapper\gradle-wrapper-bootstrap.sha256')

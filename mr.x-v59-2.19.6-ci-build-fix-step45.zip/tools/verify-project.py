#!/usr/bin/env python3
from pathlib import Path
import re, sys, xml.etree.ElementTree as ET, zipfile

ROOT = Path(__file__).resolve().parents[1]

def check(ok, msg):
    print(('PASS: ' if ok else 'FAIL: ') + msg)
    if not ok: sys.exit(1)

main = (ROOT/'app/src/main/kotlin/com/socialnetwork/app/ui/MainActivity.kt').read_text()
endpoints = (ROOT/'app/src/main/kotlin/com/socialnetwork/app/network/ServiceEndpoints.kt').read_text()
offline = (ROOT/'app/src/main/kotlin/com/socialnetwork/app/data/local/OfflineStore.kt').read_text()
gradle = (ROOT/'app/build.gradle.kts').read_text()
manifest = ROOT/'app/src/main/AndroidManifest.xml'

# Kotlin/XML structural gate.
kotlin_files = list((ROOT/'app/src/main/kotlin').rglob('*.kt'))
for p in kotlin_files:
    s = p.read_text()
    check(s.count('{') == s.count('}'), f'{p.relative_to(ROOT)} brace balance')
    check(s.count('(') == s.count(')'), f'{p.relative_to(ROOT)} parenthesis balance')
    check(s.count('[') == s.count(']'), f'{p.relative_to(ROOT)} bracket balance')
check(not list((ROOT/'app/src/main/kotlin').rglob('*.java')), 'Android source tree is Java-free')
for p in (ROOT/'app/src/main/res').rglob('*.xml'):
    ET.parse(p)
check(True, 'all resource XML parses')
ET.parse(manifest)
check(True, 'AndroidManifest parses')

# Native-only/security invariants.
all_kotlin='\n'.join(p.read_text() for p in kotlin_files)
check('android.webkit.WebView' not in all_kotlin and 'loadUrl(' not in all_kotlin, 'no WebView/browser shell')
check('http://' not in all_kotlin, 'no cleartext HTTP literal in Kotlin sources')
check('FLAG_SECURE' in main, 'screen capture protection remains enabled')
check('RejectedExecutionException' in main and 'private fun submitIo(task: () -> Unit)' in main, 'executor saturation is surfaced without UI-thread execution')
check(main.count('override fun onNewIntent(intent: Intent)') == 1, 'single onNewIntent implementation')
check('networkAvailableAtStart = isNetworkAvailable()' in main, 'offline decision is made before mutation request')
check('Do not enqueue here' in main, 'post-failure mutation is not blindly re-queued')
check('Never evict' in offline and 'MAX_PENDING_ENTRIES' in offline, 'offline queue protects existing user mutations')
check('pathFromTrustedService(value)' in endpoints and 'sameOriginOrigin' in endpoints and 'startsWith(primary)' not in endpoints, 'service routing uses origin-aware matching')
check('versionCode = 48' in gradle and 'versionName = "2.19.3"' in gradle, 'version metadata matches repair release')
check('RECOVERY_STATE_TTL_MS' in main and 'constantTimeEquals' in main and 'clearRecoveryState()' in main, 'password recovery callback is state-bound and one-time')
check('instanceFollowRedirects = false' in main, 'HTTP requests never follow redirects automatically')
check('NETWORK_CONNECT_TIMEOUT_MS' in main and 'NETWORK_READ_TIMEOUT_MS' in main, 'network timeout constants are used by authenticated requests')
check('syncInFlight = false' in main and 'offline-sync' in main, 'offline sync rejection and retry scheduling are lifecycle-safe')
check('profileUpdateInFlight = false' in main and 'peopleLoadInFlight = false' in main, 'executor rejection cannot permanently lock profile/people operations')
check('notificationsMarkReadInFlight = false' in main and 'messageSendInFlight = false' in main, 'executor rejection cannot permanently lock notification/message operations')
check('storyInFlight = false' in main and 'publishInFlight = false' in main, 'executor rejection cannot permanently lock media publishing')
check('versionCode = 48' in gradle and 'versionName = \"2.19.3\"' in gradle, 'free-policy release metadata is current')
print('PROJECT STATIC GATE: PASS')

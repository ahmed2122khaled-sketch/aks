#!/usr/bin/env python3
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
root = (ROOT / 'build.gradle.kts').read_text()
app = (ROOT / 'app/build.gradle.kts').read_text()
errors = []
checks = [
    ('AGP 9.3.1 configured', 'com.android.application") version "9.3.1"' in root),
    ('built-in Kotlin is used (legacy Kotlin Android plugin removed)', 'org.jetbrains.kotlin.android' not in root and 'org.jetbrains.kotlin.android' not in app),
    ('compileSdk 37', re.search(r'compileSdk\s*=\s*37\b', app) is not None),
    ('targetSdk 37', re.search(r'targetSdk\s*=\s*37\b', app) is not None),
    ('JDK 17 compile target', 'JavaVersion.VERSION_17' in app),
    ('Java source tree remains empty', not list((ROOT/'app/src/main').rglob('*.java'))),
    ('MainActivity imports Build API', 'import android.os.Build' in (ROOT/'app/src/main/kotlin/com/socialnetwork/app/ui/MainActivity.kt').read_text()),
    ('network timeout constants are wired', 'AppConstants.NETWORK_CONNECT_TIMEOUT_MS' in (ROOT/'app/src/main/kotlin/com/socialnetwork/app/ui/MainActivity.kt').read_text()),
    ('message update is sender-only', 'using (sender_id = auth.uid())' in (ROOT/'supabase/migrations/20260925_000000_security_hardening.sql').read_text()),
    ('system-field hardening migration exists', (ROOT/'supabase/migrations/20260925_000000_security_hardening.sql').exists()),
]
for name, ok in checks:
    print(f"[{'PASS' if ok else 'FAIL'}] {name}")
    if not ok: errors.append(name)
if errors:
    raise SystemExit('2026 modernization verification failed: ' + ', '.join(errors))
print('2026 MODERNIZATION VERIFICATION: PASS')

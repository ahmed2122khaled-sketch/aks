#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
JAR="$ROOT/gradle/wrapper/gradle-wrapper.jar"
if [ -s "$JAR" ]; then exit 0; fi
"$ROOT/tools/fetch-gradle-wrapper.sh"

# Build Compatibility — 2026-09-25

Current Step 37 toolchain:
- Android Gradle Plugin: 9.3.1
- Kotlin Gradle Plugin: 2.4.20
- Gradle wrapper: 9.7.1
- compileSdk / targetSdk: 37
- JDK target: 17

This combination is intentionally pinned instead of blindly selecting the newest individual component. Kotlin 2.4.20's fully-supported AGP range tops out at AGP 9.3.1 and its fully-supported Gradle range tops out at 9.7.0; Gradle 9.7.1 is the project wrapper and is compatible with the current Android build setup in practice. The project remains on API 37, which is supported by AGP 9.3.x.

The newer AGP 9.4.x line is documented separately, but using it here with Kotlin 2.4.20 would move outside Kotlin's stated fully-supported AGP range.

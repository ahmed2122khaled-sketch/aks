# Gradle bootstrap fallback

This repository keeps the official Gradle 9.7.1 wrapper checksum in
`gradle/wrapper/gradle-wrapper.jar.sha256` and the CI workflow fetches the
official wrapper JAR from Gradle before building.

For environments where that binary cannot be included or downloaded during
initial setup, `gradle/wrapper/gradle-wrapper.jar` is a small repository-owned
bootstrap JAR. It downloads the pinned Gradle 9.7.1 distribution, verifies its
SHA-256 checksum, caches it under the user's Gradle directory, and delegates
all Gradle arguments to that distribution.

The bootstrap is **not** presented as Gradle's official wrapper JAR. A normal
CI run replaces it with the official JAR using `tools/fetch-gradle-wrapper.sh`.

Rebuild the fallback with:

```bash
./tools/gradle-bootstrap/build.sh
```

The fallback distribution checksum is pinned in the source and the generated
bootstrap JAR checksum is recorded in `gradle/wrapper/gradle-wrapper-bootstrap.sha256`.

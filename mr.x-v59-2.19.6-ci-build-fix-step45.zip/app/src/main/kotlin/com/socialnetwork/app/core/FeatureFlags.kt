package com.socialnetwork.app.core

/** Central production-safe feature switches. */
object FeatureFlags {
    const val FEED_PAGINATION = true
    const val STORIES = true
    const val LIKES = true
    const val COMMENTS = true
    const val PROFILES = true
    const val FOLLOWS = true
    const val NOTIFICATIONS = true
    const val MESSAGES = true
}

#!/usr/bin/env python3
from pathlib import Path
import re
root = Path(__file__).resolve().parent
main = (root/'app/src/main/kotlin/com/socialnetwork/app/ui/MainActivity.kt').read_text(encoding='utf-8')
utils = (root/'app/src/main/kotlin/com/socialnetwork/app/util/AppUtils.kt').read_text(encoding='utf-8')
gradle = (root/'app/build.gradle.kts').read_text(encoding='utf-8')

checks = {
    'lifecycle postUi re-checks before execution': 'main.post {' in main and 'if (isFinishing || isDestroyed) return' in main,
    'destroy removes pending UI callbacks': 'main.removeCallbacksAndMessages(null)' in main,
    'finishing activity cleans pending camera URI': 'if (isFinishing && pendingCameraUri != null)' in main,
    'document picker uses persistable permission when provider supports it': 'takePersistableUriPermission' in main and 'FLAG_GRANT_READ_URI_PERMISSION' in main,
    'camera capture uses modern TakePicture contract': 'ActivityResultContracts.TakePicture()' in main and 'cameraCaptureLauncher.launch(uri)' in main,
    'MIME-to-extension mapping is explicit': 'mediaExtension(mime: String?)' in utils and 'image/gif' in utils and 'video/mp4' in utils,
    'unsupported MIME is rejected': 'نوع الملف غير مدعوم' in main and 'image/' in main and 'video/' in main,
    'offline queue is user-bound': 'CURRENT_USER_ID' in main and 'ownerUserId' in main and 'pendingOperationBelongsToUser' in main,
    'legacy plaintext user-id cache removed': 'prefs.getString(\"offline_user_id\"' not in main and 'prefs.edit().putString(\"offline_user_id\"' not in main,
    'request body limit exists': 'MAX_REQUEST_BODY_BYTES' in main and 'payload.size > MAX_REQUEST_BODY_BYTES' in main,
    'partial upload cleanup exists': 'cleanupUploadedPath(path,requestRefreshToken)' in main or 'cleanupUploadedPath(path, requestRefreshToken)' in main,
    'cleanup retries after refresh': 'refreshSessionIfNeeded(failedRefreshToken)' in main and 'cleanupUploadedPath' in main,
    'media URL port is constrained': 'uri.port' in utils and 'base.port' in utils and 'storage/v1/object/public/media/' in utils,
    'version bumped after hardening': (lambda m: bool(m and int(m.group(1)) >= 40))(re.search(r'versionCode\s*=\s*(\d+)', gradle)),
    'no WebView shell': not re.search(r'WebView|loadUrl\(|addJavascriptInterface|CustomTabsIntent|androidx\.browser', re.sub(r'/\*.*?\*/|//[^\n]*','',main,flags=re.S)),
    'no cleartext URL in Java': 'http://' not in main,
}
for k,v in checks.items(): print(f"[{'PASS' if v else 'FAIL'}] {k}")
if not all(checks.values()): raise SystemExit(1)
print('REGRESSION/HARDENING VERIFICATION: PASS')


#!/usr/bin/env python3
"""Detect unfinished/stubbed application code and false-success build paths."""
from pathlib import Path
import re, sys
ROOT=Path(__file__).resolve().parent
errors=[]
checks=[]
def check(name, ok, detail=''):
    checks.append((name,ok,detail))
    if not ok: errors.append(f'{name}: {detail}')

src=list((ROOT/'app/src/main/kotlin').rglob('*.kt'))
text='\n'.join(p.read_text(encoding='utf-8',errors='replace') for p in src)
for marker in [r'\bTODO\b',r'\bFIXME\b',r'UnsupportedOperationException',r'NotImplementedException',r'not implemented',r'placeholder',r'\bmock\b',r'\bdummy\b',r'\bfake\b']:
    check(f'no incomplete marker {marker}', re.search(marker,text,re.I) is None, 'unfinished implementation marker found')
# Empty catch blocks/private constructors are legitimate; unfinished methods are covered by marker checks.
check('build script fails closed', 'BUILD BLOCKED:' in (ROOT/'tools/build-linux.sh').read_text(), 'build script lacks explicit fail-closed path')
check('doctor fails closed', 'RESULT: TOOLCHAIN INCOMPLETE' in (ROOT/'tools/doctor.sh').read_text(), 'doctor script lacks incomplete-toolchain result')
check('Android source tree is Java-free', not list((ROOT/'app/src/main/kotlin').rglob('*.java')), 'Java source remains in Android tree')
check('required service client exists', (ROOT/'app/src/main/kotlin/com/socialnetwork/app/network/ServiceClients.kt').is_file(), 'ServiceClients.kt missing')

# Repository files required for a reproducible build/deploy.
required = [
    ROOT / 'gradlew', ROOT / 'gradlew.bat', ROOT / 'gradle/wrapper/gradle-wrapper.properties',
    ROOT / 'gradle/wrapper/gradle-wrapper.jar.sha256', ROOT / 'tools/fetch-gradle-wrapper.sh',
    ROOT / 'tools/fetch-gradle-wrapper.ps1', ROOT / 'supabase/config.toml',
    ROOT / 'supabase/migrations/20260924_000000_initial_schema.sql', ROOT / 'supabase/migrations/20260924_090300_high_load_indexes.sql',
    ROOT / 'supabase.properties.example', ROOT / '.gitignore',
    ROOT / 'GRADLE_BOOTSTRAP.md', ROOT / 'tools/gradle-bootstrap/GradleBootstrap.kt',
    ROOT / 'tools/gradle-bootstrap/build.sh', ROOT / 'tools/gradle-bootstrap/build.ps1',
    ROOT / 'gradle/wrapper/gradle-wrapper-bootstrap.sha256',
]
for p in required:
    check(f'required repository file {p.relative_to(ROOT)}', p.is_file(), 'required file is missing')

wrapper_sha = (ROOT/'gradle/wrapper/gradle-wrapper.jar.sha256').read_text(encoding='utf-8').split()[0].lower()
check('Gradle 9.7.1 wrapper checksum is pinned', wrapper_sha == '7a9ce74cff467ca1bf60a4fcd9f05185acceda4d0f382434d393e17864262c5d', 'unexpected wrapper checksum')

# The binary wrapper is intentionally fetched from Gradle and checksum-verified when a networked
# build environment is available; do not silently accept a zero-byte placeholder.
wrapper_jar = ROOT/'gradle/wrapper/gradle-wrapper.jar'
check('Gradle wrapper JAR is present or fetchable', wrapper_jar.is_file() or (ROOT/'tools/fetch-gradle-wrapper.sh').is_file(), 'wrapper bootstrap path is missing')

bootstrap_sha_file = ROOT/'gradle/wrapper/gradle-wrapper-bootstrap.sha256'
if wrapper_jar.is_file() and bootstrap_sha_file.is_file():
    import hashlib
    actual = hashlib.sha256(wrapper_jar.read_bytes()).hexdigest()
    pinned = bootstrap_sha_file.read_text(encoding='utf-8').split()[0].lower()
    check('bootstrap Gradle JAR checksum matches', actual == pinned or actual == wrapper_sha, 'local wrapper JAR is neither the pinned bootstrap nor the official Gradle JAR')

print('=== Completeness verification ===')
for n,ok,d in checks: print(f"[{'PASS' if ok else 'FAIL'}] {n}" + (f' — {d}' if d and not ok else ''))
if errors:
    print('\nRESULT: FAIL')
    sys.exit(1)
print('\nRESULT: PASS')
